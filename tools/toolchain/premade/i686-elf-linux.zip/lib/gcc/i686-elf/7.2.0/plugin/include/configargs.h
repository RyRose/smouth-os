/* Generated automatically. */
static const char configuration_arguments[] = "../gcc/configure --target=i686-elf --prefix=/home/ryanrose/.cache/bazel/_bazel_ryanrose/83ef91ba5c0542c57319be800614cb43/external/toolchain-i686-elf/toolchain --disable-nls --enable-languages=c,c++ --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "pentiumpro" } };
