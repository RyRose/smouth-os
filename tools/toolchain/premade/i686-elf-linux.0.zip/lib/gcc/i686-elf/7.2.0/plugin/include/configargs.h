/* Generated automatically. */
static const char configuration_arguments[] = "../gcc/configure --target=i686-elf --prefix=/home/ryanrose/.cache/bazel/_bazel_ryanrose/9ed059de0203dde8912c48287592f518/external/toolchain-i686-elf --disable-nls --enable-languages=c,c++ --without-headers";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "generic" }, { "arch", "pentiumpro" } };
